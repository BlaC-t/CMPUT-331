Cmput 331 Assignment 8 README

Student: Zhiyu Li (Titus)
Student Number: 1666065

1. The following acknowledgement of url will be all the resources I have used to write assignment 8
2. The assignment is discussed with Rui Huang on basic concepts.

# General vigenere cipher

# https://www.geeksforgeeks.org/vigenere-cipher/

# join a list of char into a single string

# https://www.simplilearn.com/tutorials/python-tutorial/list-to-string-in-python#:~:text=To%20convert%20a%20list%20to%20a%20string%2C%20use%20Python%20List,and%20return%20it%20as%20output.

# find all unique values in a string

# https://stackoverflow.com/questions/13902805/list-of-all-unique-characters-in-a-string

# sort a list of tuple by its value

# https://stackoverflow.com/questions/3121979/how-to-sort-a-list-tuple-of-lists-tuples-by-the-element-at-a-given-index

# The running time of part 3 of the assignment is: 56.16205906867981

# Reference to Assignment 6 for n-gram, key score, and frequency, Assignment 7 for key length
