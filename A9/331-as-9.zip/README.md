Cmput 331 Assignment 9 README

Student: Zhiyu Li (Titus)
Student Number: 1666065

1. The following acknowledgement of url will be all the resources I have used to write assignment 9
2. The assignment is discussed with Rui Huang on basic concepts.

# Cracking Code with Python p192

# mod Inverse function used in assignment 3 and appear in the book

# Understanding of RSA

# https://www.simplilearn.com/tutorials/cryptography-tutorial/rsa-algorithm

# https://en.wikipedia.org/wiki/RSA_(cryptosystem)

# pow() function to replace the power and %

# https://www.w3schools.com/python/ref_func_pow.asp
